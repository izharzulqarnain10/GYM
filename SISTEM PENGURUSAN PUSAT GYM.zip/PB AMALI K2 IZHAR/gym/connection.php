<?php

$servername="localhost";
$username="root";
$password="";
$dbname="gym"; // nama database


$conn=mysqli_connect("localhost","root","","gym");

//echo "berjaya";
?>