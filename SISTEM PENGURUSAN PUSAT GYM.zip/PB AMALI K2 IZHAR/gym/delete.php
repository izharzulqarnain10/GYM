<?php
include ('connection.php');
$id=$_GET['id']; //memanggil main (id) tertentu untuk memadam semua data 
$nama=$_GET ['nama'];


$query=("DELETE FROM daftar WHERE id='$id'"); // memanggil table barang_masuk untuk memadam data
$result=mysqli_query($conn, $query);
header('Location:papar.php'); // selepas berjaya memadam, akan ke paapran jadual senarai barang
?>
