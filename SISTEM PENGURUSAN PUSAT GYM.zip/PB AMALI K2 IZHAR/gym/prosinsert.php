<?php
include ('connection.php');

$id = $_GET ['id'];
$nama=$_GET ['nama'];


$sql="INSERT INTO daftar VALUES('$id','$nama')";
$sql=mysqli_query($conn, $sql);

$sql="INSERT INTO admin VALUES('$username','$password')";
$result=mysqli_query($conn, $sql);


if($result)
{
	header("Location:papar.php");
}
else{
	echo "GAGAL!";}


?>