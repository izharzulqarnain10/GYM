<html>
<head>
	<title>LOGIN </title><!-- title untuk tajuk di tab bar -->
</head>
<body>
	<body bgcolor="orange">
	<style type="text/css"><!-- style untuk mencantikkan interface -->
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
</style>
<?php
include 'connection.php' //include untuk menyambung database
?>
<center>
<br><br><br><br></br></br></br></br><!-- br untuk baris baru -->
<table border='1'><tr><td>
<form method="post">
	<table width="280px" border="0">
	<tr>
		<td align="center">Username</td>
	</tr>
	<tr>
		<td align="center"><input type="text" name="username" placeholder="Nama Pengguna"></td><!-- input untuk memasukan input -->
	</tr>
	<tr>
		<td align="center">Password</td>
	</tr>
	<tr>
		<td align="center"><input type="password" name="password" placeholder="Kata Laluan"></td><!-- input untuk memasukan input -->
	</tr>
	<tr>
		<td align="center"><button type="submit" name="submit">Login</button></td>
	</tr>
	</table>
</form>
<center>
<a href="sign_up.php"target="top"value="sign up">Sign Up</a><br></center>
</tr></td></table>
</br>


</center>

<?php
$error=''; 

if(isset($_POST['submit']))
{
 
    if(empty($_POST['username']) || empty($_POST['password']))
    {
        $error = "Username or Password is Invalid";
    }
    else{
        
      
         $username=$_POST['username'];
         $password=$_POST['password'];
        
         
         $conn = mysqli_connect("localhost", "root", "");
         
         $db = mysqli_select_db($conn, "gym");
        
         
         $query = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username' AND password='$password'");

         $rows = mysqli_num_rows($query);
         
         if($rows == 1)
         {
            header("Location: index.php"); 
         }
         else
         {
            header("Location: not-found-page.html"); 
         }
         
        mysqli_close($conn); 
    }
}
 
?>


</body>

</html>
