<html>
<head><title>TAMBAH AHLI</title>
</head>
<body>

<body style="background-color:orange;">
<center>
<img src="welcome.jpg" alt="" style="width:500px;height:200px;"/> <!-- gambar  -->

<h2>SELAMAT DATANG AHLI BARU</h2>
</center>

</div>
<div id="menu">

<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #ffea05;
}

li {
    float: left;
}

li a, .dropbtn {
    display: inline-block;
    color: black;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
    background-color: pink;
}

li.dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #d1a908;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content a:hover {background-color:pink}

.dropdown:hover .dropdown-content {
    display: block;
}
h3 {
   
	width: 50%;
}
table#t01 {
    width: 100%;    
 
}
</style>
</head>
<body>
<ul>
  <li><a href="papar.php">KEMBALI</a></li>
  
	 
	 
</ul>
</body>


<div id="kandungan">
<center>
<br>
<br>
<body>
<h3>
<fieldset>
<form action="prosinsert.php" method="get"> <!-- menghantar (get) data -->
<center>


<table id="t01">
<table>
 <tr>
    
	
<td>Id </td>
<td>:</td>
<td><input type="text" name="id"></td> 

</tr>

<td>Nama </td>
<td>:</td>
<td><input type="text" name="nama"></td>

</tr>



<td></td>
<td></td>
<br>

<td><input type="submit" value="Submit"></td>
</h3>
</tr>
</table>
</form>
</fieldset>
</tr>
</form>
</fieldset>
</center>
</body>
</html>

</html>