<?php
include ('connection.php');
?>
<style>
table{
width:800px;
margin:30px auto;
border-collapse:collapse;
text-align:center;
}
h2{
text-align:center;
}
</style>

<h2>Senarai Nama Ahli GYM</h2>
<body>

<table width="100%" border="1px" style="border-collapse:collapse;">
<thead>
<tr style="background-color:#03fcb6;">
<th>Bil</th>
<th>Id</th><br>
<th>Nama</th><br>

</tr>
</thead>

<body>
<?php 
include ('connection.php');
$no=1;
$sql=('SELECT * FROM daftar');
$ambil=mysqli_query($conn, $sql) ; // Memilih semua data untuk masuk ke dalam database gym


while($data=mysqli_fetch_array($ambil))
{?>

<tr>
		<td><?php echo $no++;?></td>
		<td><?php echo $data['id'];?></td>
		<td><?php echo $data['nama'];?></td>
</tr>

<td style="text-align:center,"><a class="" href="delete.php?id=<?php echo $data['id'];?>">Delete</a></td> <!-- Link delete apabila ditekan akan memadam data tersebut pada tabel dan database -->
<td style="text-align:center,"><a class="" href="form.php?id=<?php echo $data['id'];?>">Tambah</a></td> <!-- Link update apabila ditekan akan keluar ke paparan form update -->
<td style="text-align:center,"><a class="" href="form.php?id=<?php echo $data['id'];?>">Edit</a></td>		
<?php
	
			}
				?>

</tbody>
</tbody>




