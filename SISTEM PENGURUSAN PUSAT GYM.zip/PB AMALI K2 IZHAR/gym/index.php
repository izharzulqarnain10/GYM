<html>
<head><title>Sistem GYM</title></head><!-- title untuk tajuk di tab bar -->
<body>
<? include "connection.php"; ?><!-- include untuk menyambung database -->
<style><!-- style untuk mencantikkan interface -->
.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}


.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}


.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #d1a908;
  color: white;
}


.topnav input[type=text] {
  float: right;
  padding: 6px;
  border: none;
  margin-top: 8px;
  margin-right: 16px;
  font-size: 17px;
}

@media screen and (max-width: 600px) {
  .topnav a, .topnav input[type=text] {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;
  }
}
</style>

<body style="background-color:orange;">
<center><u><h1>PENGURUSAN GYM </h1><!-- h1 untuk saiz font paling besar -->  </u></center>

<ul>
  <div class="topnav">
  <a class="active" href="index.php">Home</a><!-- a href untuk integrasi halaman -->
  <a href="login.php">Login</a>
  <a href="papar.php">Senarai Ahli</a><!-- a href untuk integrasi halaman -->
  <a href="logout.php">Logout</a><!-- a href untuk integrasi halaman -->
  <input type="text" placeholder="Search.."> 
</div>
  
</ul>
<br><br><br><br>

<div id="kandungan"><center>
<img src="gym.jpg" width="400" height="300"> &nbsp <img src="gym2.jpg" width="400" height="300"><!-- img memasukan gambar --> </center></div>
<br></br>

<div id="footer"><center>
<img src="gym3.jpg" width="300" height="300"> <img src="gym4.jpg" width="300" height="300"> <img src="gym6.jpg" width="300" height="300"> <img src="gym5.jpg" width="300" height="300"><!-- img memasukan gambar --><br></br><br></br><!-- br untuk baris baru --?

<img src="5.jpg" width="300" height="300"><img src="6.jpg" width="300" height="300"><img src="7.jpg" width="300" height="300"><img src="8.jpg" width="300" height="300"><!-- img memasukan gambar -->
</div>
</div></center>

</body>
</html>