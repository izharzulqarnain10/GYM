<!DOCTYPE html>
<html>
<head>
<title>SIGN UP </title><!-- title untuk tajuk di tab bar -->

</head>
<body>
 <body bgcolor="orange"><!-- background colour-->
 	
<center>
	<p><h1><strong><center>Sign Up</center></strong></h1><!-- h1 untuk saiz font paling besar -->
		<form id="form"name="form"method="post"action="signup_process.php">
			<table width="400" border="1"><!-- table untuk menyediakan sesebuah jadual -->
			
				<tr>
					<th scope="col">Username:</th>
					<th scope="col"><div align="left">
					<input type="text" name="username"value=""size="50"/>
				</div>
			</th>
		</tr>
		<tr>
					<th scope="col">Password:</th>
					<th scope="col"><div align="left">
					<input type="password" name="password"value=""size="50"/>
				</div>
			</th>
		</tr>
		
	</table>
	<br>
	<center><button type="submit"value="submit">Hantar</button><!-- button untuk butang -->
		<button type="reset"value="reset">Isi Semula</button><!-- button untuk butang -->
	</br>
</form>
</br>
</br>
<a href="login.php"target="-top">Kembali</a><br><!-- a href untuk link -->
</center>
</form>
</p>
</center>
</body>
</html>